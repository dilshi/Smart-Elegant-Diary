from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.views.generic import TemplateView,ListView, DetailView, CreateView
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login, authenticate
from textblob import TextBlob

# Create your views here.
from django.contrib.auth.models import User
from .forms import MemoriesForm,SignUpForm
from .models import Memories,Userdetails
uname='defaultname'

class Voiceloginview(ListView):
    template_name= 'voicelogin.html'
    
    def get(self, request):
        return render(request,'voicelogin.html')
    def post(self, request):
        testingvoice = request.POST['avgvoice']
        giveninputlist=[]
        workinginputlist=[]
        giveninputlist=testingvoice.split(',')
        for i in giveninputlist:
            workinginputlist.append(float(i))
        uservoice=[]
        rowcount=Userdetails.objects.all().count()
        queryset=Userdetails.objects.all()
        for row in queryset:
            uservoice.append(row.voicerec)
        individualvoice=[]
        floatindividualvoice=[]
        splicefloatindivoice=[]
        diffvoice=[]
        #splitfloatindividualvoice=[]
        for j in uservoice:
            j=j.split(',')
            individualvoice.append(j)
        for j in individualvoice:
            for k in j:
                floatindividualvoice.append(float(k))
        n=int(len(floatindividualvoice)/rowcount)
        splicefloatindivoice=[floatindividualvoice[i:i+n] for i in range(0, len(floatindividualvoice), n)]
        #print(len(splicefloatindivoice))
        differenceresult=[]
        temp=1
        start=0
        val=0
        for x in range(int(len(splicefloatindivoice))):
            for z in range(int(len(splicefloatindivoice[x]))):
                differenceresult.append(abs(workinginputlist[z]-splicefloatindivoice[x][z]))
                        
##        while(temp<rowcount):
##            for x in range(start,(180*temp)):
##                differenceresult.append(abs(workinginputlist[x]-splicefloatindivoice[temp-1][x]))
##                val=val+1
##            start=(180*temp)
##            temp=temp+1
        sumofdiff=[]
        splicedifferenceresult=[differenceresult[i:i+n] for i in range(0, len(differenceresult), n)]
        for x in range(int(len(splicedifferenceresult))):
            sumofdiff.append(sum(splicedifferenceresult[x]))
        identifiedindex=(sumofdiff.index(min(sumofdiff))+1)
        qset=Userdetails.objects.filter(userno=identifiedindex)
        for col in qset:
            identifieduname=col.username
        global uname
        uname=identifieduname
        #print(identifieduname)
        print("!!!!!!!!!!!!!!!!!!")
        print(sumofdiff)
        #print(val)
        #print(splicedifferenceresult)
        #print("!!!!!!!!!!!!!!!!!!")
        #print(len(splicedifferenceresult))

        #splitfloatindivi[floatindividualvoice[i:i+180] for i in range(0, len(floatindividualvoice), 180)]
        #diffindividualvoice=[]
        #for j in individualvoice:
        #    for k in range(len(j)):
        #        diffindividualvoice.append(abs(workinginputlist[k]-j[k]))
        return redirect('home.html',{'username':uname})
        #return redirect('home.html',{'username':uname})
        
class Loginview(ListView):
    template_name= 'login.html'
    
    def get(self, request):
        return render(request,'login.html')
    def post(self, request):
        username=request.POST['username']
        password=request.POST['password']
        usercount=Userdetails.objects.filter(username=username,password=password).count()
        if usercount==1:
            global uname
            uname=username
            return redirect('home.html',{'username':uname})
        else:
            return render(request,self.template_name,{'msg':"Please enter a valid Username and password!!!"})

class Signupview(ListView):
    template_name= 'signup.html'
    
    def get(self, request):
        return render(request, 'signup.html')
    def post(self, request):
        username=request.POST['username']
        firstname=request.POST['firstname']
        lastname=request.POST['lastname']
        emailid=request.POST['emailid']
        password=request.POST['password']
        confpassword=request.POST['confpassword']
        voicerec=request.POST['avgvoice']
        totalcount=Userdetails.objects.all().count()
        unamecount=Userdetails.objects.filter(username=username).count()
        if unamecount==0:
            global uname
            uname=username
            Userdetails.objects.create(username=username,userno=(totalcount+1),firstname=firstname,lastname=lastname,emailid=emailid,password=password,confpassword=confpassword,voicerec=voicerec)
            return redirect('home.html',{'username':uname})
        else:
            return render(request,self.template_name,{'msg':"Username already exists!!!"})

##def signup(request):
##    if request.method == 'POST':
##        form = SignUpForm(request.POST)
##        if form.is_valid():
##            form.save()
##            username = form.cleaned_data.get('username')
##            raw_password = form.cleaned_data.get('password1')
##            user = authenticate(username=username, password=raw_password)
##            login(request, user)
##            return render(request, "home.html")#redirect('../home.html')
##    else:
##        form = SignUpForm()
##    return render(request, 'signup.html', {'form': form})

class Homeview(TemplateView):
    template_name='home.html'

    def get(self, request):        
        return render(request,'home.html',{'username':uname})

    def post(self, request):
        username=request.POST['username']
        textmemory=request.POST['textmemory']
        tagname=request.POST['tagname']
        location=request.POST['location']
        image=request.FILES['imagememory']
        voice=request.FILES['voicememory']
        #voice_address= 'audios/'+tagname+'.mp3'
        #with open(voice_address,'wb+') as destination:
        #    for chunk in request.META['voicememory'].chunks():
        #        destination.write(chunk)
        #    audio = MP3(voice_address)
        
        blob = TextBlob(textmemory)
        blob.tags           # [('The', 'DT'), ('titular', 'JJ'),
                    #  ('threat', 'NN'), ('of', 'IN'), ...]

        blob.noun_phrases   # WordList(['titular threat', 'blob',
                    #            'ultimate movie monster',
                    #            'amoeba-like mass', ...])

        #for sentence in blob.sentences:
        #print(sentence)
        #print(blob.sentences)
        #analysis=TextBlob(str(sentence))
        analysis=TextBlob(str(blob.sentences))

        #print(analysis.sentiment)
        #print("")
        #print(analysis.sentiment.polarity)
        polarity=analysis.sentiment.polarity
        if(polarity <=1.0 and polarity >0.5):
            returnvalue=1
        elif(polarity <=0.5 and polarity >0):
            returnvalue=2
        elif(polarity <=0 and polarity >-0.5):
            returnvalue=3
        else:
            returnvalue=4
        emoji=str(returnvalue)
        print(type(image))
        Memories.objects.create(username=username,textmemory=textmemory,tagname=tagname,location=location,voice=voice,emoji=emoji,image=image)
        #returnvalue="your polarity value is:"+str(polarity)
        args1={'text':returnvalue}
        return render(request, self.template_name,args1)
    
def search(request):
    context = {
    }
    return render(request, "search.html", context)

class Searchbytagnameview(ListView):
    template_name= 'searchbytagname.html'
    
    def get(self, request):
        return render(request, 'searchbytagname.html')
    def post(self, request):
        searchbytagname=request.POST['searchbytagname']
        queryset=Memories.objects.filter(username=uname,tagname__icontains=searchbytagname)
        
        return render(request, self.template_name,{'object_list':queryset,'tagname':'Tagname','textmemory':'Memory','image':'Image','voice':'Voice','location':'Location','timestamp':'Date & time','emptyqueryset':'Sorry No memories Found'})
        #return redirect("../../searchresults.html")

class Searchbylocationview(ListView):
    template_name= 'searchbylocation.html'
    
    def get(self, request):
        return render(request, 'searchbylocation.html')
    def post(self, request):
        searchbylocation=request.POST['searchbylocation']
        queryset=Memories.objects.filter(username=uname,location__icontains=searchbylocation)
        
        return render(request, self.template_name,{'object_list':queryset,'tagname':'Tagname','textmemory':'Memory','image':'Image','voice':'Voice','location':'Location','timestamp':'Date & time','emptyqueryset':'Sorry No memories Found'})

class Searchbymemoriesview(ListView):
    template_name= 'searchbymemories.html'
    
    def get(self, request):
        return render(request, 'searchbymemories.html')
    def post(self, request):
        searchbymemories=request.POST['searchbymemories']
        queryset=Memories.objects.filter(username=uname,textmemory__icontains=searchbymemories)
        
        return render(request, self.template_name,{'object_list':queryset,'tagname':'Tagname','textmemory':'Memory','image':'Image','voice':'Voice','location':'Location','timestamp':'Date & time','emptyqueryset':'Sorry No memories Found'})

class Searchbydateview(ListView):
    template_name= 'searchbydate.html'
    
    def get(self, request):
        return render(request, 'searchbydate.html')
    def post(self, request):
        searchbydate=request.POST['searchbydate']
        queryset=Memories.objects.filter(username=uname,timestamp__icontains=searchbydate)
        return render(request, self.template_name,{'object_list':queryset,'tagname':'Tagname','textmemory':'Memory','image':'Image','voice':'Voice','location':'Location','timestamp':'Date & time','emptyqueryset':'Sorry No memories Found'})

def timeseries(request):
    queryset=Memories.objects.filter(username=uname)
    count=Memories.objects.filter(username=uname).count()
    return render(request,"timeseries.html",{'object_list':queryset,'count':count})

def hr(request):
    context = {
    }
    return render(request, "hr.html", context)

def about(request):
    context = {
    }
    return render(request, "about.html", context)

def fors(request):
    queryset=User.objects.all()
    return render(request, "fors.html",{'object_list':queryset})

def upload(request):
    context = {
    }
    return render(request, "upload.html", context)

##def webapp_create(request):
##    form = MemoriesForm(request.POST or None)
##    if form.is_valid():
##        instance =form.save(commit=False)
##        instance.save()
##    context={
##        "form":form,
##        }
##    return render(request,"forms.html",context) 
##def webapp_detail(request):
##    queryset = Memories.objects.all()
##    context={
##        "object_list":queryset
##    }
##    return render(request,"index.html",context) 
##    #return HttpResponse("<h1>detail</h1>")
##
##def webapp_list(request):
##    return HttpResponse("<h1>list</h1>")
##
##def webapp_update(request):
##    return HttpResponse("<h1>update</h1>")
##
##def webapp_delete(request):
##    return HttpResponse("<h1>delete</h1>")
