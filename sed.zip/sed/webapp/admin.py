from django.contrib import admin

# Register your models here.
from .models import Memories,Userdetails

class MemoriesModelAdmin(admin.ModelAdmin):
	list_display = ["username","tagname","textmemory","location","updated","timestamp","image","voice","emoji"]
	
	class Meta:
		model = Memories

class UserdetailsModelAdmin(admin.ModelAdmin):
	list_display = ["username","userno","firstname","lastname","emailid","password","confpassword","loginpin","voicerec"]
	
	class Meta:
		model = Userdetails		

admin.site.register(Memories, MemoriesModelAdmin)
admin.site.register(Userdetails, UserdetailsModelAdmin)
