{% load staticfiles %}
var mic, recorder, soundFile,vol,testvol;
var totaldiff=0;
var volhistory= new Array();
var rec1=new Array(180);
var testvolhistory=new Array(180);
var testarray=new Array(180);
var diff=new Array(180);
var outputstring='';
var count=0;
function setup() {
  mic = new p5.AudioIn();

  mic.start();

  recorder = new p5.SoundRecorder();

  recorder.setInput(mic);

  soundFile = new p5.SoundFile();
  //amp=new p5.Amplitude();
  document.getElementById("disp").innerHTML = "click and speak your pin";
}
function testvoice() {
	if (mic.enabled) {
	draw=function(){
	vol = mic.getLevel();
	volhistory.push(vol);
	//console.log(vol);
	//console.log(volhistory.length);
	return;
	}
    recorder.record(soundFile);
    document.getElementById("disp").innerHTML = "recording your voice";}
	setTimeout("stoprecord()",3000);}
 }
stoprecord=function(){
    recorder.stop();
	//saveSound(soundFile, 'recordedvoice.wav');
	document.getElementById("disp").innerHTML = "recorded your voice";
	//console.log(volhistory.length);
	rec1=volhistory.slice(0,180);
	if(rec1.length<180){
		while(rec1.length<180){
		rec1.push(rec1[(rec1.length)-1]);
	}
	}
	for(var i=0; i<rec1.length;i++){
	rec1[i]=rec1[i]*100000;
	}
	console.log(rec1);

for(var i=0;i<180;i++){
	stravg[i]=rec1[i].toString();
}
outputstring=stravg.join(",");
//for(var i=0; i<180; i++){
//	outputstring=outputstring+avg[i]+'!';
//}
//	console.log(outputstring);
	document.getElementById("avg").value = outputstring;
	console.log(outputstring);
	//document.getElementById("avg").innerHTML = avg;
}
/*if(count==3){
	var testbutton = document.createElement("button");
	document.getElementById("disp").innerHTML = "click and test your voice";
	testbutton.innerHTML = "Click to test it";
	//document.getElementById("htmltestbutton").innerHTML=testbutton;
	var body = document.getElementsByTagName("body")[0];
	body.appendChild(testbutton);
	testbutton.addEventListener ("click", testvoice());
function testvoice(){	
	draw=function(){
	testvol = mic.getLevel();
	testvolhistory.push(testvol);
	//console.log(vol);
	//console.log(volhistory.length);
	return;
	}
	recorder.record(soundFile);
	count=count+1;
	if(count==3){
	document.getElementById("disp").innerHTML = "Recording the test voice";	
	}
	setTimeout("stoptestvoice()",3000);	
}
stoptestvoice=function(){
    recorder.stop();
	saveSound(soundFile, 'testvoice.wav');
	noLoop();
	console.log(testvolhistory);
	testarray=testvolhistory.slice(0,180);
	document.getElementById("disp").innerHTML = "Recorded the test voice";
	validate();
	}
function validate(){
for(var i=0;i<180;i++){
	diff[i]=Math.abs(testarray[i]-avg[i]);
}
console.log(diff);
for(var i=0;i<180;i++){
totaldiff=totaldiff+diff[i];
}
console.log(totaldiff);
//getSum=function(total, num) {
 //   return (total + num);
//}
//function myFunction(item) {
 //   totaldiff = diff.reduce(getSum);
//}
}
}*/
