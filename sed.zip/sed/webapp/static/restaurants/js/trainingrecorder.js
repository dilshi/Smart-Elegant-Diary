{% load staticfiles %}
var mic, recorder, soundFile,vol,testvol;
var totaldiff=0;
var volhistory= new Array();
var rec1=new Array(180);
var rec2=new Array(180);
var rec3=new Array(180);
var avg=new Array(180);
var testvolhistory=new Array(180);
var testarray=new Array(180);
var diff=new Array(180);
var outputstring='';
var count=0;
function setup() {
  mic = new p5.AudioIn();

  mic.start();

  recorder = new p5.SoundRecorder();

  recorder.setInput(mic);

  soundFile = new p5.SoundFile();
  //amp=new p5.Amplitude();
  document.getElementById("disp").innerHTML = "click and speak your pin";
}
function trainingrecord() {
	if (mic.enabled && count<3) {
	draw=function(){
	vol = mic.getLevel();
	volhistory.push(vol);
	//console.log(vol);
	//console.log(volhistory.length);
	return;
	}
    recorder.record(soundFile);
    count=count+1;
    if(count==1){
	document.getElementById("disp").innerHTML = "recording 1st voice";}
	else if(count==2){
	loop();
	document.getElementById("disp").innerHTML = "recording 2nd voice";}
	else{
	loop();//reexecute the draw function
	document.getElementById("disp").innerHTML = "recording 3rd voice";}
	setTimeout("stoprecord()",3000);}
  }
stoprecord=function(){
    recorder.stop();
	//saveSound(soundFile, 'recordedvoice.wav');
	noLoop();//stops the draw function
	if(count==1){
	document.getElementById("disp").innerHTML = "recorded 1st voice";
	document.getElementById("trainingvoice").src = "{% static 'restaurants/img/no2.png'%}";
	//console.log(volhistory.length);
	rec1=volhistory.slice(0,180);
	if(rec1.length<180){
		while(rec1.length<180){
		rec1.push(rec1[(rec1.length)-1]);
	}
	}
	for(var i=0; i<rec1.length;i++){
	rec1[i]=rec1[i]*100000;
	}
	console.log(rec1);
	document.getElementById("arr1").innerHTML = rec1;
	}
	else if(count==2){
	document.getElementById("disp").innerHTML = "recorded 2nd voice";
	document.getElementById("trainingvoice").src= "{% static 'restaurants/img/no1.png'%}";
	rec2=volhistory.slice(180,360);
	if(rec2.length<180){
		while(rec2.length<180){
		rec2.push(rec2[(rec2.length)-1]);
	}
	}
	for(var i=0; i<rec2.length;i++){
	rec2[i]=rec2[i]*100000;
	}
	console.log(rec2);
	document.getElementById("arr2").innerHTML = rec2;
	}
	else{
	document.getElementById("disp").innerHTML = "Thank you for your pin";
	document.getElementById("trainingvoice").src = "{% static 'restaurants/img/done.png'%}";
	rec3=volhistory.slice(360,540);
	if(rec3.length<180){
		while(rec3.length<180){
		rec3.push(rec3[(rec3.length)-1]);}
	}
	for(var i=0; i<rec3.length;i++){
	rec3[i]=rec3[i]*100000;
	}
	console.log(rec3);
	document.getElementById("arr3").innerHTML = rec3;
	calcaverage();
	}
calcaverage=function(){
for(var i=0; i<180; i++){
avg[i]=((rec1[i]+rec2[i]+rec3[i])/3);
}
for(var i=0;i<180;i++){
	avg[i]=avg[i].toString();
}
for(var i=0; i<180; i++){
	outputstring=outputstring+avg[i]+'!';
}
	console.log(outputstring);
	//document.getElementById("avg").innerHTML = avg;
}
/*if(count==3){
	var testbutton = document.createElement("button");
	document.getElementById("disp").innerHTML = "click and test your voice";
	testbutton.innerHTML = "Click to test it";
	//document.getElementById("htmltestbutton").innerHTML=testbutton;
	var body = document.getElementsByTagName("body")[0];
	body.appendChild(testbutton);
	testbutton.addEventListener ("click", testvoice());
function testvoice(){	
	draw=function(){
	testvol = mic.getLevel();
	testvolhistory.push(testvol);
	//console.log(vol);
	//console.log(volhistory.length);
	return;
	}
	recorder.record(soundFile);
	count=count+1;
	if(count==3){
	document.getElementById("disp").innerHTML = "Recording the test voice";	
	}
	setTimeout("stoptestvoice()",3000);	
}
stoptestvoice=function(){
    recorder.stop();
	saveSound(soundFile, 'testvoice.wav');
	noLoop();
	console.log(testvolhistory);
	testarray=testvolhistory.slice(0,180);
	document.getElementById("disp").innerHTML = "Recorded the test voice";
	validate();
	}
function validate(){
for(var i=0;i<180;i++){
	diff[i]=Math.abs(testarray[i]-avg[i]);
}
console.log(diff);
for(var i=0;i<180;i++){
totaldiff=totaldiff+diff[i];
}
console.log(totaldiff);
//getSum=function(total, num) {
 //   return (total + num);
//}
//function myFunction(item) {
 //   totaldiff = diff.reduce(getSum);
//}
}
}*/
}
