var mic, recorder, soundFile;
var state = 0; // mousePress will increment from Record, to Stop, to Play
function setup() {
  // create an audio in
  mic = new p5.AudioIn();
  // users must manually enable their browser microphone for recording to work properly!
  mic.start();
  // create a sound recorder
  recorder = new p5.SoundRecorder();
  // connect the mic to the recorder
  recorder.setInput(mic);
  // create an empty sound file that we will use to playback the recording
  soundFile = new p5.SoundFile();
}
function recordinput() {
if (state === 0 && mic.enabled) {
	recorder.record(soundFile);
	document.getElementById("disp").innerHTML = "recording";
	state++;
}
else if (state === 1) {
recorder.stop();
document.getElementById("disp").innerHTML = "recorded";
state--;
//findurl();
var objurl=URL.createObjectURL(soundFile);
document.getElementById("voice").src=objurl;
//saveSound(soundFile, 'mySound.wav');
//soundFile.play(); play recorded voice
}
}
function findurl(){

}
