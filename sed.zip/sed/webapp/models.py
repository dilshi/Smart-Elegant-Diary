from django.db import models


# Create your models here.
class Memories(models.Model):

    username = models.CharField(default='',max_length=120)
    textmemory = models.TextField()
    #imagememory = models.ImageField()
    #voicememory = models.FileField()
    updated = models.DateTimeField(auto_now=True, auto_now_add=False)
    timestamp = models.DateTimeField(auto_now=False, auto_now_add=True)
    tagname = models.CharField(max_length=120,default='')
    location = models.CharField(max_length=50,default='')
    emoji = models.CharField(max_length=2,default='')
    image = models.FileField(null=True, blank=True)
    voice = models.FileField(null=True, blank=True)
    
    def __unicode__(self):
        return self.tagname
    
    def __str__(self):
        return self.tagname

class Userdetails(models.Model):

    userno = models.CharField(default='',max_length=3)
    username = models.CharField(default='',max_length=120)
    firstname = models.CharField(default='',max_length=120)
    lastname = models.CharField(default='',max_length=120)
    emailid = models.CharField(default='',max_length=120)
    password = models.CharField(default='',max_length=120)
    confpassword = models.CharField(default='',max_length=120)
    voicerec = models. TextField(default='')
    loginpin = models.CharField(default='',max_length=4)

    def __unicode__(self):
        return self.username
    
    def __str__(self):
        return self.username
